create view pg_timezone_abbrevs(abbrev, utc_offset, is_dst) as
SELECT abbrev,
       utc_offset,
       is_dst
FROM pg_timezone_abbrevs() pg_timezone_abbrevs(abbrev, utc_offset, is_dst);

alter table pg_timezone_abbrevs
    owner to postgres;

grant select on pg_timezone_abbrevs to public;

